# Tetriduels
Final CPT multiplayer project for ICS4U1.
https://github.com/henryinqz/Tetriduels

## Instructions
1. Download 'Tetriduels.zip'
2. Unzip the file
3. Ensure you have Java Runtime installed (https://java.com/en/download/)
4. Execute 'Tetriduels.jar'

## Authors
- Henry Wong
- Zuhair Siddiqi
- Jeremy Selwin
